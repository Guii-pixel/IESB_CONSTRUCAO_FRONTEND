import Pagina from "./components/Pagina";

export default function page() {
  return (
  
      <Pagina titulo="Copas do Mundo">

        <p></p>

      </Pagina>

  )
}